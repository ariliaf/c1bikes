﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication1
{
    public partial class CategoryPassholder : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            string Constr = ConfigurationManager.ConnectionStrings["BikeDataConnectionString"].ConnectionString;
            

            SqlConnection sqlConnection1 = new SqlConnection(Constr);
            SqlCommand cmd = new SqlCommand();
            SqlDataReader reader;

            cmd.CommandText = "[GetCategory-Passholder]";
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Connection = sqlConnection1;

            sqlConnection1.Open();

            reader = cmd.ExecuteReader();
            // Data is accessible through the DataReader object here.

            GridViewCategoryPlace.DataSource = reader;
            GridViewCategoryPlace.DataBind();
            sqlConnection1.Close();
        }
    }
}