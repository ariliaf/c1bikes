﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication1
{
    public partial class GetCountByStartimePerSeason : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
           
            string Constr = ConfigurationManager.ConnectionStrings["BikeDataConnectionString"].ConnectionString;
           

            SqlConnection sqlConnection1 = new SqlConnection(Constr);
            SqlCommand cmd = new SqlCommand();
            SqlDataReader reader;

            cmd.CommandText = "GetCountByStartimePerSeason";
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Connection = sqlConnection1;

            sqlConnection1.Open();

            reader = cmd.ExecuteReader();
            // Data is accessible through the DataReader object here.
            GridView1.DataSource = reader;
            GridView1.DataBind();

           
            sqlConnection1.Close();



            GetDatawithDurationAndbindtoGrid();
            GetDatawithDistanceAndbindtoGrid();

        }
        //[GetCountByStartimePerSeasonWithDistance]
        public void GetDatawithDurationAndbindtoGrid()
        {
            string Constr = ConfigurationManager.ConnectionStrings["BikeDataConnectionString"].ConnectionString;


            SqlConnection sqlConnection1 = new SqlConnection(Constr);
            SqlCommand cmd = new SqlCommand();
            SqlDataReader reader;

            cmd.CommandText = "GetCountByStartimePerSeasonWithDuration";
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Connection = sqlConnection1;

            sqlConnection1.Open();

            reader = cmd.ExecuteReader();
            // Data is accessible through the DataReader object here.
            GridView2.DataSource = reader;
            GridView2.DataBind();


            sqlConnection1.Close();
        }

        public void GetDatawithDistanceAndbindtoGrid()
        {
            string Constr = ConfigurationManager.ConnectionStrings["BikeDataConnectionString"].ConnectionString;


            SqlConnection sqlConnection1 = new SqlConnection(Constr);
            SqlCommand cmd = new SqlCommand();
            SqlDataReader reader;

            cmd.CommandText = "GetCountByStartimePerSeasonWithDistance";
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Connection = sqlConnection1;
            cmd.CommandTimeout = 360;
            sqlConnection1.Open();

            reader = cmd.ExecuteReader();
            // Data is accessible through the DataReader object here.
            GridView3.DataSource = reader;
            GridView3.DataBind();


            sqlConnection1.Close();
        }
    }
}