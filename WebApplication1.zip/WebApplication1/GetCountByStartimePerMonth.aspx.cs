﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication1
{
    public partial class GetCountByStartimePerMonth : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
           
            string Constr = ConfigurationManager.ConnectionStrings["BikeDataConnectionString"].ConnectionString;
            //var select = "EXEC  [dbo].[GetStartStationPopular]";
            //var c = new SqlConnection(Constr); // Your Connection String here
            //var dataAdapter = new SqlDataAdapter(select, c);

            //var commandBuilder = new SqlCommandBuilder(dataAdapter);


            //var ds = new DataSet();
            //dataAdapter.Fill(ds);



         
          //  GridViewStationStartPopular.DataSource = ds.Tables[0];
            ////

            SqlConnection sqlConnection1 = new SqlConnection(Constr);
            SqlCommand cmd = new SqlCommand();
            SqlDataReader reader;

            cmd.CommandText = "GetCountByStartimePerMonth";
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Connection = sqlConnection1;

            sqlConnection1.Open();

            reader = cmd.ExecuteReader();
            // Data is accessible through the DataReader object here.
            GridView1.DataSource = reader;
            GridView1.DataBind();
            sqlConnection1.Close();






        }
    }
}