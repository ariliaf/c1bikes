﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.OleDb;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication1
{
    public partial class _Default : Page
    {
      

        protected void Page_Load(object sender, EventArgs e)
        {


            LabelADT.Text = "3.372"; //  GetADT().Substring(0, 5);
            LabelBikeShareUsers.Text = "81304";   // GetBSD();


            //FileUpload sFile; ;

            //   SaveFileToDatabase(GetLocalFilePath(@"\\phoenix\public$\Ashok\ADS\20181015ADS\", @"Adhoc_ULTA_WorldSpendQualifiers.csv"));

            //  SaveFileToDatabase(@"\\phoenix\public$\Ashok\ADS\20181015ADS\Adhoc_ULTA_WorldSpendQualifiers.csv");

            //  SaveFileToDatabase(@"C:\ADS\Adhoc_ULTA_WorldSpendQualifiers.csv");

        }

        private void SaveFileToDatabase(string filePath)
        {




            //var fileName = string.Format("{0}{1}", AppDomain.CurrentDomain.BaseDirectory, "Upload\\");
            //string connectionString = string.Format(@"Provider=Microsoft.Jet.OLEDB.4.0; Data Source={0}; Extended Properties=""text;HDR=YES;FMT=Delimited""", "Adhoc_ULTA_WorldSpendQualifiers.csv");
            //OleDbConnection oledbConn = new OleDbConnection(connectionString);
            //oledbConn.Open();

                                                                 

            //filePath = System.IO.Path.Combine(@"C:\ADS\",@"Adhoc_ULTA_WorldSpendQualifiers.csv");
            // filePath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, @"Upload\Adhoc_ULTA_WorldSpendQualifiers.csv");


            // filePath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, @"C:\ADS\Adhoc_ULTA_WorldSpendQualifiers.xlsx");

            filePath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, @"C:\ADS\capitalonebike.xlsx");

            SqlConnection conn = new SqlConnection();
            //conn.ConnectionString =
            //"Data Source=B1-PLOYDB01V,1422;" +
            //"Initial Catalog=LPS1_Work;" +
            //"Integrated Security=SSPI;";

            conn.ConnectionString =
           "Data Source=tlasisibike.database.windows.net;" +
           "Initial Catalog=BikeData;" +
           "User Id = tlasisi;" +
               "Password = TajudeenLasisi123;";

                       

            // conn.Open();

            //   public static string path = @"C:\src\RedirectApplication\RedirectApplication\301s.xlsx";
            //  public static string connStr = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + path + ";Extended Properties=Excel 12.0;";

            //  String strConnection = "Data Source=.\\SQLEXPRESS;AttachDbFilename='C:\\Users\\Hemant\\documents\\visual studio 2010\\Projects\\CRMdata\\CRMdata\\App_Data\\Database1.mdf';Integrated Security=True;User Instance=True";

            // String excelConnString = String.Format("Provider=Microsoft.ACE.OLEDB.12.0;Data Source={0};Extended Properties=\"Excel 12.0\"", filePath);
            //   String excelConnString = String.Format("Provider=Microsoft.ACE.OLEDB.12.0;Data Source={0};Extended Properties=\"Text;HDR=Yes;FORMAT=Delimited\",", filePath);
            String excelConnString = String.Format("Provider=Microsoft.ACE.OLEDB.12.0;Data Source={0};Extended Properties=\"Excel 12.0;HDR=YES;IMEX=1;\"", filePath);

            //    "Provider=Microsoft.Jet.OleDb.4.0; Data Source = " + System.IO.Path.GetDirectoryName(strFileName) + "; Extended Properties = \"Text;HDR=YES;FMT=Delimited\""

            // Extended Properties=\"Text;HDR=Yes;FORMAT=Delimited\""
            //
            // String excelConnString = String.Format("Provider=Microsoft.Jet.OleDb.4.0;;Data Source={0};Extended Properties = \"Text;HDR=YES;FMT=Delimited\"", filePath);

            //Create Connection to Excel work book 
            //    using (OleDbConnection excelConnection = new OleDbConnection(excelConnString))

            using (OleDbConnection excelConnection = new OleDbConnection(excelConnString))
            {
                //Create OleDbCommand to fetch data from Excel 
                // using (OleDbCommand cmd = new OleDbCommand("Select [ID],[Name],[Designation] from [Sheet1$]", excelConnection))
                // using (OleDbCommand cmd = new OleDbCommand("Select [LAST_NAME], [STR_ADDR], [SEC_STR_ADDR], [CITY], [STATE], [ZIP_CD], [ZIP_PLUS4], [ZIP_PLUS6], [prescreen_id], [tier], [card_type], [recipient_id], [CUST_MEMBER_ID], [list_id], [version], [campaign_type], [control_flag], [offer_expires] , [filler_A], [filler_B]  from [Adhoc_ULTA_WorldSpendQualifiers$]", excelConnection))

                using (OleDbCommand cmd = new OleDbCommand("Select * from [metro$]", excelConnection))

                {
                    excelConnection.Open();
                    using (OleDbDataReader dReader = cmd.ExecuteReader())

                    using (SqlBulkCopy sqlBulk = new SqlBulkCopy(conn.ConnectionString))
                    {
                        //Give your Destination table name   
                        //  sqlBulk.DestinationTableName = "Adhoc_ULTA_WorldSpendQualifiers";
                        sqlBulk.BulkCopyTimeout = 180;
                        sqlBulk.DestinationTableName = "CapitalOneBikeData7";
                        sqlBulk.WriteToServer(dReader);
                    }
                }

            }
        }

        private string GetADT()
        {
            string outstr ="";

            string Constr = ConfigurationManager.ConnectionStrings["BikeDataConnectionString"].ConnectionString;
            
            SqlConnection sqlConnection1 = new SqlConnection(Constr);
            SqlCommand cmd = new SqlCommand();
            SqlDataReader reader;

            cmd.CommandText = "GetAverageDistance";
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Connection = sqlConnection1;
            cmd.CommandTimeout = 260;
            sqlConnection1.Open();

            reader = cmd.ExecuteReader();
            // Data is accessible through the DataReader object here.
            if (reader.Read())
            {
                outstr = reader["AVGMIles"].ToString();
            }
          
            sqlConnection1.Close();

            return outstr;
        }
        private string GetBSD()
        {
            string outstr = "";

            string Constr = ConfigurationManager.ConnectionStrings["BikeDataConnectionString"].ConnectionString;

            SqlConnection sqlConnection1 = new SqlConnection(Constr);
            SqlCommand cmd = new SqlCommand();
            SqlDataReader reader;

            cmd.CommandText = "[GetUserThatUseBikeShare]";
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Connection = sqlConnection1;
            cmd.CommandTimeout = 260;
            sqlConnection1.Open();

            reader = cmd.ExecuteReader();
            // Data is accessible through the DataReader object here.
            if (reader.Read())
            {
                outstr = reader[0].ToString();
            }

            sqlConnection1.Close();

            return outstr;
        }
        private string GetLocalFilePath(string saveDirectory, FileUpload fileUploadControl)
        {
            
            string filePath = Path.Combine(saveDirectory, fileUploadControl.FileName);

            fileUploadControl.SaveAs(filePath);

            return filePath;

        }

        private string ToSignificantDigits(
   string value, int significant_digits)
        {
            // Use G format to get significant digits.
            // Then convert to double and use F format.
            string format1 = "{0:G" + significant_digits.ToString() + "}";
            string result = Convert.ToDouble(
                String.Format(format1, value)).ToString("F99");

            // Rmove trailing 0s.
            result = result.TrimEnd('0');

            // Rmove the decimal point and leading 0s,
            // leaving just the digits.
            string test = result.Replace(".", "").TrimStart('0');

            // See if we have enough significant digits.
            if (significant_digits > test.Length)
            {
                // Add trailing 0s.
                result += new string('0', significant_digits - test.Length);
            }
            else
            {
                // See if we should remove the trailing decimal point.
                if ((significant_digits < test.Length) &&
                    result.EndsWith("."))
                    result = result.Substring(0, result.Length - 1);
            }

            return result;
        }

    }
}